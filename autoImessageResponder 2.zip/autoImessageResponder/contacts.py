CONTACTS = {
    '+1 number': 'name',

    }

YOUR_NUMBER = '+1 your number'
